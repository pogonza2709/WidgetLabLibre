# Widget Lab Libre

Proyecto inicial de Android nativo, sin anuncios ni suscripciones. No modifica ni reutiliza el APK original de Widget Lab.

## Funciones incluidas
- Pantalla principal de estilo oscuro.
- Vista previa de hora y fecha.
- Widget básico de reloj/fecha para la pantalla de inicio.
- Sin SDK de anuncios ni sistema de compras integrado.

## Cómo compilar
1. Abre la carpeta del proyecto en Android Studio.
2. Deja que Gradle sincronice las dependencias.
3. Ve a **Build > Build APK(s)**.
4. Android Studio generará el APK de depuración en `app/build/outputs/apk/debug/`.

## Cómo probar el widget
Mantén pulsada una zona vacía de la pantalla de inicio del teléfono → Widgets → Widget Lab Libre → arrastra el widget.

## Limitaciones de esta primera versión
Es una base inicial. El widget de reloj se actualiza cuando Android lo programa; Android limita las actualizaciones periódicas frecuentes para ahorrar batería. No incluye aún clima real, reproductor multimedia ni editor visual de temas.
