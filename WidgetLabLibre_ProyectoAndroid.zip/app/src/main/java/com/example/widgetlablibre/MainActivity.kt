package com.example.widgetlablibre

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = Color.rgb(8, 13, 32)
        val panel = Color.rgb(21, 30, 61)
        val accent = Color.rgb(83, 111, 255)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(bg)
        }
        fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, dp(8), 0, dp(8))
            }
        root.addView(label("Widget Lab Libre", 28f, Color.WHITE, true))
        root.addView(label("Tus widgets, a tu estilo", 16f, Color.LTGRAY))
        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setBackgroundColor(panel)
        }
        val now = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        preview.addView(label(now, 42f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        preview.addView(label(java.text.SimpleDateFormat("EEEE, d MMMM", java.util.Locale.getDefault()).format(java.util.Date()), 16f, Color.LTGRAY).apply { gravity = Gravity.CENTER })
        preview.addView(label("Personaliza tu pantalla de inicio", 14f, Color.rgb(165, 184, 255)).apply { gravity = Gravity.CENTER })
        root.addView(preview, LinearLayout.LayoutParams(-1, dp(170)).apply { bottomMargin = dp(18) })
        root.addView(label("Incluye", 20f, Color.WHITE, true))
        listOf(
            "• Sin anuncios ni suscripciones",
            "• Widget de reloj y fecha para la pantalla de inicio",
            "• Diseño oscuro con acentos de color",
            "• Proyecto abierto para agregar más widgets"
        ).forEach { root.addView(label(it, 15f, Color.LTGRAY)) }
        val button = Button(this).apply {
            text = "Cómo agregar el widget"
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
            setTextColor(Color.WHITE)
            setOnClickListener {
                Toast.makeText(this@MainActivity,
                    "Mantén pulsada la pantalla de inicio → Widgets → Widget Lab Libre → arrastra el reloj.",
                    Toast.LENGTH_LONG).show()
            }
        }
        root.addView(button, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(18) })
        setContentView(root)
    }
}
